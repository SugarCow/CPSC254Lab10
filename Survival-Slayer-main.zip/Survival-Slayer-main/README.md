# Survival-Slayer

To run game, in terminal/ IDE: python3 main.py
